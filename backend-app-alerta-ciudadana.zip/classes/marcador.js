

class Marcador{
    constructor() {
        id ='',
        nombre='',
        vehiculo='',
        id_vehiculo='',
        lng,
        lat,
        color=''
    }
}

module.exports = Marcador;